package com.sb_security;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringSecurityUrlApplicationTests {

	@Test
	void contextLoads() {
	}

}
