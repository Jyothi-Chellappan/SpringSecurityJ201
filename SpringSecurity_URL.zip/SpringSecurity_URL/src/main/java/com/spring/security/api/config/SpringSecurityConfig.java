package com.spring.security.api.config;
//This class is used to customise the spring security.

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.crypto.password.NoOpPasswordEncoder;

@SuppressWarnings("deprecation")
@Configuration
public class SpringSecurityConfig extends WebSecurityConfigurerAdapter {
	
	@Override
	protected void configure(AuthenticationManagerBuilder auth) throws Exception {
		//basic Authentication based on user,password,role
		auth.inMemoryAuthentication().withUser("Adminuser").password("Adminpassword").roles("ADMIN");
		auth.inMemoryAuthentication().withUser("User1").password("User1password").roles("USER");
	}

	// security for all API
	//disabling csrf token
	//For every request security is implemented
/*	@Override 
	 protected void configure(HttpSecurity http) throws Exception {
	 http.csrf().disable();
	 http.authorizeRequests().anyRequest().fullyAuthenticated().and().
	 httpBasic();
	 }*/
	
	// security based on URL
	
	  @Override 
	  protected void configure(HttpSecurity http) throws Exception {
	  http.csrf().disable();
     http.authorizeRequests().antMatchers("/rest/**").fullyAuthenticated().and
	 ().httpBasic(); 
     }
		
	
}
