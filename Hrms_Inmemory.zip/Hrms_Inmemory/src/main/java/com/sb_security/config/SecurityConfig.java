package com.sb_security.config;
/*import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;
@Configuration
@EnableWebSecurity
public class SecurityConfig extends WebSecurityConfigurerAdapter {
	@Override
	protected void configure(AuthenticationManagerBuilder auth) throws Exception {
		// {noop} => No operation for password encoder	(no password encoding needed)
		auth.inMemoryAuthentication().withUser("devs").password("{noop}devs").authorities("ADMIN");
		auth.inMemoryAuthentication().withUser("ns").password("{noop}ns").authorities("EMPLOYEE");
		auth.inMemoryAuthentication().withUser("vs").password("{noop}vs").authorities("MANAGER");
	}
	@Override
	protected void configure(HttpSecurity http) throws Exception {
		//declares which Page(URL) will have What access type
		http.authorizeRequests()
		.antMatchers("Home","/Home").permitAll()
		.antMatchers("Welcome","/Welcome").authenticated()
		.antMatchers("Admin","/Admin").hasAuthority("ADMIN")
		.antMatchers("Emp","/Emp").hasAuthority("EMPLOYEE")
		.antMatchers("Mgr","/Mgr").hasAuthority("MANAGER")
		.antMatchers("Common","/Common").hasAnyAuthority("EMPLOYEE","MANAGER")
		
		// Any other URLs which are not configured in above antMatchers
		// generally declared aunthenticated() in real time
		.anyRequest().authenticated()
		//Login Form Details
		.and()
		.formLogin()
		.defaultSuccessUrl("/Welcome", true)
		
		//Logout Form Details
		.and()
		.logout()
		.logoutRequestMatcher(new AntPathRequestMatcher("/logout"))
		//Exception Details		
				.and()	
				.exceptionHandling()
				.accessDeniedPage("/AccessDeniedPage");
			}
		}*/

import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;

@Configuration
@EnableWebSecurity
public class SecurityConfig extends WebSecurityConfigurerAdapter {

	@Override
	protected void configure(AuthenticationManagerBuilder auth) throws Exception {
		
		// {noop} => No operation for password encoder	(no password encoding needed)
    	auth.inMemoryAuthentication().withUser("devs").password("{noop}devs").authorities("ADMIN");
		auth.inMemoryAuthentication().withUser("ns").password("{noop}ns").authorities("EMPLOYEE");
		auth.inMemoryAuthentication().withUser("vs").password("{noop}vs").authorities("MANAGER");
	}
	
	@Override
	protected void configure(HttpSecurity http) throws Exception {
		
		//declares which Page(URL) will have What access type
		http.authorizeRequests()
		.antMatchers("/Home").permitAll()
		//.antMatchers("/WelcomePage").authenticated()
		.antMatchers("/Admin").hasAuthority("ADMIN")
		.antMatchers("/Emp").hasAuthority("EMPLOYEE")
		.antMatchers("/Mgr").hasAuthority("MANAGER")
		.antMatchers("/Common").hasAnyAuthority("EMPLOYEE","MANAGER")
		
		// Any other URLs which are not configured in above antMatchers
		// generally declared aunthenticated() in real time
		.anyRequest().authenticated()
		
		//Login Form Details
		.and()
		.formLogin()
		.defaultSuccessUrl("/WelcomePage", true)
		
		//Logout Form Details
		.and()
		.logout()
		.logoutRequestMatcher(new AntPathRequestMatcher("/logout"))
				
		//Exception Details		
		.and()	
		.exceptionHandling()
		.accessDeniedPage("/AccessDeniedPage")
		;
	}
}
