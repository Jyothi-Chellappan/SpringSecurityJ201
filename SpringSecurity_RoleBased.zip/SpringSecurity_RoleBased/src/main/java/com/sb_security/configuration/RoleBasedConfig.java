package com.sb_security.configuration;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.crypto.password.NoOpPasswordEncoder;

	@SuppressWarnings("deprecation")
	@Configuration
	public class RoleBasedConfig extends WebSecurityConfigurerAdapter {
		
		@Override
		protected void configure(AuthenticationManagerBuilder auth) throws Exception {
			//basic Authentication based on user,password,role
			auth.inMemoryAuthentication().withUser("admin").password("admin").roles("ADMIN");
			auth.inMemoryAuthentication().withUser("user1").password("user1").roles("USER");
		}

				
		// security based on URL
		
		  /*@Override 
		  protected void configure(HttpSecurity http) throws Exception {
		  http.csrf().disable();
	     http.authorizeRequests().antMatchers("/rest/**").fullyAuthenticated().and
		 ().httpBasic(); 
	     }*/
		 
		//security based on ROLE
		@Override
		protected void configure(HttpSecurity http) throws Exception {
			http.csrf().disable();
			http.authorizeRequests().antMatchers("/admin/**").hasAnyRole("ADMIN").anyRequest().fullyAuthenticated().and()
					.httpBasic();
		}
	
		//password encryption is not required.
		@Bean
		public static NoOpPasswordEncoder passwordEncoder() {
			return (NoOpPasswordEncoder) NoOpPasswordEncoder.getInstance();
		}
		
	}
