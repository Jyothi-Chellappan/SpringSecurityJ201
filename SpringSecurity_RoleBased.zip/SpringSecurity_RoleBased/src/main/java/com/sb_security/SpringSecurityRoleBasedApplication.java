package com.sb_security;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringSecurityRoleBasedApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringSecurityRoleBasedApplication.class, args);
	}

}
