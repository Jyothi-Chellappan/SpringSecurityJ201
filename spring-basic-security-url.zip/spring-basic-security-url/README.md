# spring-basic-security
Spring Security : Basic Authentication and Authorization  using spring boot
