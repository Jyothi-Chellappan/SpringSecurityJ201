package com.sb_security.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
@Controller
public class HomeController {
	
	@GetMapping("/Home")
	public String getHomePage() {
		return "HomePage";
	}
	
	@GetMapping("/Welcome")
	public String getWelcomePage() {
		return "WelcomePage";
	}
	
	@GetMapping("/Admin")
	public String getAdminPage() {
		return "AdminPage";
	}
	@GetMapping("/Emp")
	public String getEmployeePage() {
		return "EmpPage";
	}
	
	@GetMapping("/Mgr")
	public String getManagerPage() {
		return "MgrPage";
	}
	
	@GetMapping("/Common")
	public String getCommonPage() {
		return "CommonPage";
	}
	
	@GetMapping("/AccessDenied")
	public String getAccessDeniedPage() {
		return "AccessDeniedPage";
	}
}
